/* Executes agent tool calls against the live zustand store — this is what
   makes every agent edit appear instantly in the UI. Runs in the browser,
   invoked by the WebSocket bridge (see socket.js).

   Every write returns two extra fields, stripped before reaching the model:
   - `undo`: the inverse operation (applyUndoOp) for single-edit revert
   - `detail`: humanized field changes for the per-turn edit review list */

import { useTrip, useUI, useRoutes, activeTrip } from '../store'
import { bestInsertion, searchPlaces, chainedDayCoords, estimateDayKm, estimateTravel } from '../lib/geo'
import { dayDate, fmtDate, fmtMoney, costByType, fuelCost, uid, GAS_UNITS } from '../lib/utils'
import { classify } from '../lib/categories'
import i18n from '../i18n'

/* i18n note: `detail` rows and FIELD_LABELS are USER-visible (edit-review
   chips in the chat) and follow the UI language. Error messages, `hint`,
   `note` and `promemoria` strings are MODEL-facing only — they stay Italian
   on purpose (the model reads them fine in any conversation language):
   do not "fix" them in future i18n sweeps. */
import { getPlaceImages } from '../components/ItemImage'

export const WRITE_TOOLS = new Set([
  'add_activity', 'update_activity', 'remove_activity', 'move_activity',
  'add_day', 'update_day', 'remove_day', 'move_day', 'set_trip_meta',
  'checklist_add', 'checklist_toggle', 'checklist_remove', 'toggle_suggestion',
  'add_suggestion', 'remove_suggestion',
])

/* an answered question batch the agent hasn't written to the notebook yet:
   the next ask_user is refused until update_notes runs (models forget
   soft reminders; a hard tool error is impossible to ignore) */
let notesPending = false

/* callbacks registered by socket.js (avoids a module cycle) */
export const hooks = { onProgress: null, onStartPlanning: null, onAskUser: null, onNotebook: null, onProposeHotels: null, onProposeRestaurants: null }

/* i18n keys, resolved with i18n.t at execution time (UI language) */
const FIELD_LABELS = {
  title: 'fields.title', type: 'fields.type', time: 'fields.time', dur: 'fields.dur', price: 'fields.price',
  notes: 'fields.notes', links: 'fields.links', must: 'fields.must', done: 'fields.done',
  lat: 'fields.position', lng: 'fields.position', night: 'fields.night', startDate: 'fields.startDate',
  lPer100: 'fields.consumption', gasPrice: 'fields.fuel', gasUnit: 'fields.fuelUnit', model: 'fields.car',
}

const trip = () => {
  const t = activeTrip(useTrip.getState())
  if (!t) throw new Error('Nessun viaggio aperto: apri un viaggio dalla dashboard.')
  return t
}

const dayByNumber = (n) => {
  const d = trip().days[n - 1]
  if (!d) throw new Error(`Il giorno ${n} non esiste (il viaggio ha ${trip().days.length} giorni).`)
  return d
}

const findItem = (itemId) => {
  for (const [di, d] of trip().days.entries()) {
    const idx = d.items.findIndex((i) => i.id === itemId)
    if (idx >= 0) return { day: d, dayNumber: di + 1, index: idx, item: d.items[idx] }
  }
  throw new Error(`Attività ${itemId} non trovata: rileggi lo stato con get_trip.`)
}

const flash = (itemId, color) => useUI.getState().setFocusItem(itemId, color)

const fmtVal = (field, v) => {
  if (v == null || v === '') return '—'
  if (field === 'dur') return i18n.t('units.durMin', { m: v })
  if (field === 'price') return fmtMoney(v, activeTrip(useTrip.getState())?.currency ?? 'USD')
  if (field === 'must' || field === 'done') return v ? i18n.t('common.yes') : i18n.t('common.no')
  if (field === 'links') return i18n.t('fields.linkCount', { count: v.length })
  if (typeof v === 'number') return String(Math.round(v * 1000) / 1000)
  return String(v).length > 40 ? String(v).slice(0, 37) + '…' : String(v)
}

const diffDetail = (prev, patch) => {
  const rows = []
  const seen = new Set()
  for (const k of Object.keys(patch)) {
    const label = FIELD_LABELS[k] ? i18n.t(FIELD_LABELS[k]) : k
    if (seen.has(label)) continue
    seen.add(label)
    if (JSON.stringify(prev[k]) === JSON.stringify(patch[k])) continue
    rows.push({ field: label, from: fmtVal(k, prev[k]), to: fmtVal(k, patch[k]) })
  }
  return rows
}

/* map agent-facing fields -> store item fields */
const toPatch = (a) => {
  const p = {}
  if (a.title !== undefined) p.title = a.title
  if (a.type !== undefined) p.type = a.type
  if (a.transport_mode !== undefined) p.mode = a.transport_mode
  if (a.time !== undefined) p.time = a.time
  if (a.duration_min !== undefined) p.dur = a.duration_min
  if (a.price_usd !== undefined) p.price = a.price_usd
  if (a.notes !== undefined) p.notes = a.notes
  if (a.links !== undefined) p.links = a.links
  if (a.must_see !== undefined) p.must = a.must_see
  if (a.done !== undefined) p.done = a.done
  if (a.lat !== undefined) p.lat = a.lat
  if (a.lng !== undefined) p.lng = a.lng
  if (a.category !== undefined) p.category = a.category
  return p
}

const itemView = (it) => ({
  item_id: it.id,
  type: it.type,
  title: it.title,
  time: it.time || undefined,
  duration_min: it.dur || undefined,
  price_usd: it.price || undefined,
  must_see: it.must || undefined,
  done: it.done || undefined,
  lat: it.lat ?? undefined,
  lng: it.lng ?? undefined,
  notes: it.notes ? (it.notes.length > 160 ? it.notes.slice(0, 157) + '…' : it.notes) : undefined,
})

const EXECUTORS = {
  get_trip(a) {
    const t = trip()
    const costs = costByType(t)
    const km = chainedDayCoords(t).reduce((s, l) => {
      const road = useRoutes.getState().byDay[l.dayId]
      return s + (road ?? estimateDayKm(l.coords))
    }, 0)
    const dayFilter = a?.day_number
    return {
      title: t.title,
      start_date: t.startDate || null,
      transport: t.transport,
      brief: t.brief || undefined,
      notes: t.notes || undefined,
      currency: t.currency ?? 'USD',
      car: { model: t.car.model || undefined, l_per_100km: t.car.lPer100, gas_price: t.car.gasPrice, gas_unit: t.car.gasUnit },
      budget: { ...costs, fuel: Math.round(fuelCost(km, t.car, t.currency ?? 'USD')), total: Math.round(costs.items + fuelCost(km, t.car, t.currency ?? 'USD')) },
      total_km: Math.round(km),
      days: t.days
        .map((d, i) => ({
          day_number: i + 1,
          title: d.title,
          night: d.night || undefined,
          date: t.startDate ? fmtDate(dayDate(t.startDate, i), { weekday: 'short', day: 'numeric', month: 'short' }) : undefined,
          items: dayFilter && dayFilter !== i + 1 ? undefined : d.items.map(itemView),
          item_count: d.items.length,
        }))
        .filter((d) => !dayFilter || d.day_number === dayFilter || true),
      checklist: dayFilter ? undefined : t.checklist.map((c) => ({ check_id: c.id, text: c.text, done: c.done })),
    }
  },

  add_activity(a) {
    const t = trip()
    const item = {
      id: uid(),
      type: a.type ?? 'activity',
      title: a.title,
      time: a.time ?? '',
      dur: a.duration_min ?? 0,
      notes: a.notes ?? '',
      links: a.links ?? [],
      must: !!a.must_see,
      done: false,
      lat: a.lat ?? null,
      lng: a.lng ?? null,
      imgs: [],
      noWiki: false,
      sug: null,
      price: a.price_usd ?? 0,
      mode: (a.type ?? 'activity') === 'drive' ? (a.transport_mode ?? 'car') : null,
    }
    let dayId, index
    const wantsOptimal = a.optimal_placement ?? a.day_number == null
    if (wantsOptimal && item.lat != null) {
      const spot = bestInsertion(t, { lat: item.lat, lng: item.lng })
      dayId = spot.dayId
      index = spot.index
    } else if (a.day_number != null) {
      const d = dayByNumber(a.day_number)
      dayId = d.id
      index = a.index ?? d.items.length
    } else {
      throw new Error('Serve day_number oppure lat/lng (con optimal_placement) per aggiungere la tappa.')
    }
    useTrip.getState().insertItemAt(dayId, index, item)
    const dayNumber = trip().days.findIndex((d) => d.id === dayId) + 1
    flash(item.id, trip().days[dayNumber - 1].color)
    return {
      ok: true, item_id: item.id, day_number: dayNumber, index,
      undo: { op: 'remove_item', dayId, itemId: item.id },
      detail: [
        { field: i18n.t('fields.stop'), from: '—', to: item.title },
        ...(item.time ? [{ field: i18n.t('fields.time'), from: '—', to: item.time }] : []),
        ...(item.price ? [{ field: i18n.t('fields.price'), from: '—', to: fmtVal('price', item.price) }] : []),
      ],
    }
  },

  update_activity(a) {
    const { day, dayNumber, item } = findItem(a.item_id)
    const patch = toPatch(a)
    const prevPatch = Object.fromEntries(Object.keys(patch).map((k) => [k, item[k]]))
    useTrip.getState().updateItem(day.id, item.id, patch)
    flash(item.id, day.color)
    return {
      ok: true, item_id: item.id, day_number: dayNumber, item: itemView({ ...item, ...patch }),
      undo: { op: 'update_item', dayId: day.id, itemId: item.id, patch: prevPatch },
      detail: diffDetail(item, patch),
      title: item.title,
    }
  },

  remove_activity(a) {
    const { day, dayNumber, index, item } = findItem(a.item_id)
    useTrip.getState().removeItem(day.id, item.id)
    return {
      ok: true, removed: item.title, day_number: dayNumber,
      undo: { op: 'insert_item', dayId: day.id, index, item: structuredClone(item) },
      detail: [{ field: i18n.t('fields.removed'), from: item.title, to: '—' }],
      lat: item.lat, lng: item.lng,
    }
  },

  move_activity(a) {
    const { day: fromDay, dayNumber: fromN, index: fromIndex, item } = findItem(a.item_id)
    let dayId, index
    if ((a.optimal_placement ?? a.day_number == null) && item.lat != null) {
      const spot = bestInsertion(trip(), { lat: item.lat, lng: item.lng })
      dayId = spot.dayId
      index = spot.index
    } else if (a.day_number != null) {
      const d = dayByNumber(a.day_number)
      dayId = d.id
      index = a.index ?? d.items.length
    } else {
      throw new Error('Serve day_number oppure optimal_placement (con posizione nota) per spostare la tappa.')
    }
    useTrip.getState().relocateItem(item.id, dayId, index)
    const dn = trip().days.findIndex((d) => d.id === dayId) + 1
    flash(item.id, trip().days[dn - 1].color)
    return {
      ok: true, item_id: item.id, day_number: dn, index, title: item.title,
      undo: { op: 'relocate_item', itemId: item.id, dayId: fromDay.id, index: fromIndex },
      detail: [{ field: i18n.t('fields.day'), from: i18n.t('common.dayN', { n: fromN }), to: i18n.t('common.dayN', { n: dn }) }],
    }
  },

  add_day(a) {
    useTrip.getState().addDay({ title: a.title, night: a.night })
    const t = trip()
    const day = t.days[t.days.length - 1]
    return {
      ok: true, day_number: t.days.length,
      undo: { op: 'remove_day', dayId: day.id },
      detail: [{ field: i18n.t('fields.day'), from: '—', to: a.title }],
    }
  },

  update_day(a) {
    const d = dayByNumber(a.day_number)
    const patch = {}
    if (a.title !== undefined) patch.title = a.title
    if (a.night !== undefined) patch.night = a.night
    if (a.color !== undefined) patch.color = a.color
    const prev = Object.fromEntries(Object.keys(patch).map((k) => [k, d[k]]))
    useTrip.getState().updateDay(d.id, patch)
    return {
      ok: true, day_number: a.day_number,
      undo: { op: 'update_day', dayId: d.id, patch: prev },
      detail: diffDetail(d, patch),
    }
  },

  remove_day(a) {
    const d = dayByNumber(a.day_number)
    const index = a.day_number - 1
    useTrip.getState().removeDay(d.id)
    return {
      ok: true, removed: d.title,
      undo: { op: 'insert_day', index, day: structuredClone(d) },
      detail: [{ field: i18n.t('fields.dayRemoved'), from: d.title, to: '—' }],
    }
  },

  move_day(a) {
    const d = dayByNumber(a.day_number)
    useTrip.getState().moveDay(d.id, a.direction === 'up' ? -1 : 1)
    return {
      ok: true,
      undo: { op: 'move_day', dayId: d.id, dir: a.direction === 'up' ? 1 : -1 },
      detail: [{ field: i18n.t('fields.order'), from: i18n.t('fields.positionN', { n: a.day_number }), to: i18n.t('fields.positionN', { n: a.direction === 'up' ? a.day_number - 1 : a.day_number + 1 }) }],
    }
  },

  set_trip_meta(a) {
    const t = trip()
    const s = useTrip.getState()
    const prev = { title: t.title, startDate: t.startDate, car: { ...t.car }, subtitle: t.subtitle, transport: t.transport }
    const detail = []
    if (a.title !== undefined) { detail.push({ field: i18n.t('fields.title'), from: t.title, to: a.title }); s.setTitle(a.title) }
    if (a.subtitle !== undefined) { detail.push({ field: i18n.t('fields.subtitle'), from: t.subtitle || '—', to: a.subtitle }); s.setSubtitle(a.subtitle) }
    if (a.transport !== undefined) { detail.push({ field: i18n.t('fields.transport'), from: t.transport, to: a.transport }); s.setTransport(a.transport) }
    if (a.currency !== undefined) { detail.push({ field: i18n.t('fields.currency'), from: t.currency ?? '—', to: a.currency }); s.setCurrency(a.currency) }
    if (a.start_date !== undefined) { detail.push({ field: i18n.t('fields.startDate'), from: t.startDate || '—', to: a.start_date }); s.setStartDate(a.start_date) }
    if (a.car_l_per_100km !== undefined) { detail.push({ field: i18n.t('fields.consumption'), from: `${t.car.lPer100} L/100km`, to: `${a.car_l_per_100km} L/100km` }); s.setCar({ lPer100: a.car_l_per_100km }) }
    if (a.car_model !== undefined) { detail.push({ field: i18n.t('fields.car'), from: t.car.model || '—', to: a.car_model }); s.setCar({ model: a.car_model }) }
    if (a.car_gas_price !== undefined) {
      const unit = GAS_UNITS[a.car_gas_unit] ? a.car_gas_unit : t.car.gasUnit
      detail.push({ field: i18n.t('fields.fuel'), from: `${t.car.gasPrice} ${GAS_UNITS[t.car.gasUnit].short}`, to: `${a.car_gas_price} ${GAS_UNITS[unit].short}` })
      s.setCar({ gasPrice: a.car_gas_price, gasUnit: unit })
    } else if (a.car_gas_usd_per_gal !== undefined) {
      detail.push({ field: i18n.t('fields.fuel'), from: `${t.car.gasPrice} ${GAS_UNITS[t.car.gasUnit].short}`, to: `${a.car_gas_usd_per_gal} $/gal` })
      s.setCar({ gasPrice: a.car_gas_usd_per_gal, gasUnit: 'usd_gal' })
    }
    return { ok: true, undo: { op: 'set_meta', prev }, detail }
  },

  checklist_add(a) {
    const id = uid()
    useTrip.getState().addCheck(a.text, id)
    return {
      ok: true, check_id: id,
      undo: { op: 'check_remove', id },
      detail: [{ field: i18n.t('fields.checklist'), from: '—', to: a.text }],
    }
  },
  checklist_toggle(a) {
    const c = trip().checklist.find((c) => c.id === a.check_id)
    if (!c) throw new Error('Voce checklist non trovata.')
    useTrip.getState().toggleCheck(a.check_id)
    return {
      ok: true,
      undo: { op: 'check_toggle', id: a.check_id },
      detail: [{ field: c.text.slice(0, 40), from: i18n.t(c.done ? 'fields.doneState' : 'fields.todoState'), to: i18n.t(c.done ? 'fields.todoState' : 'fields.doneState') }],
    }
  },
  checklist_remove(a) {
    const t = trip()
    const index = t.checklist.findIndex((c) => c.id === a.check_id)
    if (index < 0) throw new Error('Voce checklist non trovata.')
    const item = structuredClone(t.checklist[index])
    useTrip.getState().removeCheck(a.check_id)
    return {
      ok: true,
      undo: { op: 'check_insert', index, item },
      detail: [{ field: i18n.t('fields.checklist'), from: item.text, to: '—' }],
    }
  },

  set_trip_brief(a) {
    useTrip.getState().setBrief(a.brief)
    return { ok: true }
  },

  /* the agent's per-trip notebook: full-replace markdown memory */
  update_notes(a) {
    notesPending = false
    useTrip.getState().setNotes(a.notes ?? '')
    hooks.onNotebook?.()
    return { ok: true }
  },

  add_suggestion(a) {
    const type = ['activity', 'food', 'hotel'].includes(a.type) ? a.type : 'activity'
    const sug = {
      id: uid(),
      title: a.title,
      type,
      category: a.category ?? classify(type, a.title),
      dur: a.duration_min ?? 60,
      notes: a.notes ?? '',
      lat: a.lat ?? null,
      lng: a.lng ?? null,
      must: !!a.recommended,
      links: [],
    }
    useTrip.getState().addSuggestion(sug)
    return {
      ok: true, suggestion_id: sug.id,
      undo: { op: 'remove_suggestion', id: sug.id },
      detail: [{ field: i18n.t('fields.suggestion'), from: '—', to: sug.title }],
    }
  },

  remove_suggestion(a) {
    const t = trip()
    const sug = t.suggestions.find((s) => s.id === a.suggestion_id)
    if (!sug) throw new Error('Consiglio non trovato: usa list_suggestions.')
    useTrip.getState().removeSuggestion(sug.id)
    return {
      ok: true,
      undo: { op: 'add_suggestion', sug: structuredClone(sug) },
      detail: [{ field: i18n.t('fields.suggestion'), from: sug.title, to: '—' }],
    }
  },

  async start_planning(a) {
    const s = useTrip.getState()
    if (a.brief) s.setBrief(a.brief)
    if (a.title) s.setTitle(a.title)
    if (a.subtitle) s.setSubtitle(a.subtitle)
    if (a.transport) s.setTransport(a.transport)
    if (a.start_date) s.setStartDate(a.start_date)
    if (a.car_l_per_100km) s.setCar({ lPer100: a.car_l_per_100km })
    if (a.car_gas_usd_per_gal) s.setCar({ gasPrice: a.car_gas_usd_per_gal, gasUnit: 'usd_gal' })
    /* anchor the map on the destination before the planner view mounts,
       so it never opens on the previous default while the trip is empty */
    if (a.destination) {
      try {
        const hit = (await searchPlaces(a.destination))[0]
        if (hit) s.setCenter({ lat: hit.lat, lng: hit.lng })
      } catch { /* no anchor: the map fits as soon as stops appear */ }
    }
    s.setPhase('active')
    hooks.onStartPlanning?.()
    return { ok: true, note: "Planner aperto: l'utente ora vede itinerario e mappa. Prosegui con la pianificazione completa usando report_progress ad ogni fase." }
  },

  report_progress(a) {
    if (Array.isArray(a.steps) && a.steps.length) {
      for (const step of a.steps) hooks.onProgress?.({ step, status: 'pending' })
    }
    if (a.step) hooks.onProgress?.(a)
    return { ok: true }
  },

  /* interactive question carousel: resolves when the user has answered ALL
     the questions in the UI. The reminder rides on every result: the model
     updates the notebook far more reliably when nudged in-band than by the
     system prompt alone. */
  ask_user(a) {
    if (!hooks.onAskUser) throw new Error('Interfaccia domande non disponibile.')
    if (notesPending) {
      throw new Error(
        "Risposte precedenti non ancora annotate: chiama PRIMA update_notes col blocco note completo aggiornato, POI rifai le domande con ask_user.",
      )
    }
    return new Promise((resolve) =>
      hooks.onAskUser(a, (res) => {
        if (res?.ok) {
          notesPending = true
          resolve({ ...res, promemoria: 'Aggiorna ORA il blocco note con update_notes includendo TUTTE queste risposte in una sola chiamata, prima di qualsiasi altra domanda.' })
        } else {
          resolve(res)
        }
      }),
    )
  },

  /* interactive hotel picker: resolves when the user picks one (or none) */
  propose_hotels(a) {
    if (!hooks.onProposeHotels) throw new Error('Interfaccia proposte non disponibile.')
    if (!Array.isArray(a.options) || a.options.length < 2) {
      throw new Error('Servono almeno 2 opzioni (con nome, prezzo/notte e url da search_hotels).')
    }
    return new Promise((resolve) => hooks.onProposeHotels(a, resolve))
  },

  /* interactive restaurant picker: resolves when the user picks one (or none) */
  propose_restaurants(a) {
    if (!hooks.onProposeRestaurants) throw new Error('Interfaccia proposte non disponibile.')
    if (!Array.isArray(a.options) || a.options.length < 2) {
      throw new Error('Servono almeno 2 opzioni (con nome, rating e url da search_restaurants).')
    }
    return new Promise((resolve) => hooks.onProposeRestaurants(a, resolve))
  },

  async estimate_travel(a) {
    return await estimateTravel({ lat: a.from_lat, lng: a.from_lng }, { lat: a.to_lat, lng: a.to_lng }, a.mode)
  },

  async search_places(a) {
    const results = await searchPlaces(a.query)
    if (!results.length) return { results: [], hint: 'Nessun risultato: prova ad aggiungere città o stato.' }
    return { results: results.slice(0, 5) }
  },

  async get_place_images(a) {
    const imgs = await getPlaceImages(a.lat, a.lng)
    if (!imgs.length) return { images: [], hint: 'Nessuna foto trovata per queste coordinate.' }
    return { images: imgs.slice(0, 5) }
  },

  list_suggestions() {
    const t = trip()
    const active = new Map()
    t.days.forEach((d, di) => d.items.forEach((it) => { if (it.sug) active.set(it.sug, di + 1) }))
    return {
      suggestions: t.suggestions.map((s) => {
        const isOn = active.has(s.id)
        const spot = isOn ? null : bestInsertion(t, s)
        return {
          suggestion_id: s.id,
          title: s.title,
          type: s.type,
          duration_min: s.dur,
          recommended: !!s.must,
          active: isOn,
          day_number: isOn ? active.get(s.id) : t.days.findIndex((d) => d.id === spot?.dayId) + 1 || undefined,
          added_km: spot?.addedKm,
          notes: s.notes,
        }
      }),
    }
  },

  toggle_suggestion(a) {
    const sug = trip().suggestions.find((s) => s.id === a.suggestion_id)
    if (!sug) throw new Error(`Suggerimento "${a.suggestion_id}" inesistente: usa list_suggestions.`)
    const t = trip()
    const found = (() => {
      for (const d of t.days) {
        const idx = d.items.findIndex((i) => i.sug === sug.id)
        if (idx >= 0) return { day: d, idx, item: d.items[idx] }
      }
      return null
    })()
    if (found) {
      useTrip.getState().removeSuggestionItem(sug.id)
      return {
        ok: true, action: 'removed', title: sug.title,
        undo: { op: 'insert_item', dayId: found.day.id, index: found.idx, item: structuredClone(found.item) },
        detail: [{ field: i18n.t('fields.suggestion'), from: sug.title, to: '—' }],
        lat: sug.lat, lng: sug.lng,
      }
    }
    const spot = bestInsertion(t, sug)
    const item = {
      id: uid(), type: sug.type, title: sug.title, time: '', dur: sug.dur, notes: sug.notes,
      links: sug.links ?? [], must: !!sug.must, done: false, lat: sug.lat, lng: sug.lng,
      imgs: [], noWiki: false, sug: sug.id, price: 0,
    }
    useTrip.getState().insertItemAt(spot.dayId, spot.index, item)
    const dn = trip().days.findIndex((d) => d.id === spot.dayId) + 1
    flash(item.id, trip().days[dn - 1].color)
    return {
      ok: true, action: 'added', title: sug.title, day_number: dn, added_km: spot.addedKm, item_id: item.id,
      undo: { op: 'remove_item', dayId: spot.dayId, itemId: item.id },
      detail: [{ field: i18n.t('fields.suggestion'), from: '—', to: sug.title }],
    }
  },

  get_route_info() {
    const t = trip()
    const byDay = useRoutes.getState().byDay
    const chains = chainedDayCoords(t)
    const days = chains.map((l, i) => ({
      day_number: i + 1,
      road_km: Math.round(byDay[l.dayId] ?? estimateDayKm(l.coords)),
      declared_drive_min: t.days[i].items.filter((x) => x.type === 'drive').reduce((s, x) => s + (x.dur || 0), 0),
    }))
    return { days, total_km: days.reduce((s, d) => s + d.road_km, 0) }
  },
}

export async function executeTool(name, args) {
  const fn = EXECUTORS[name]
  if (!fn) throw new Error(`Tool sconosciuto: ${name}`)
  /* the interview must hand off through start_planning before anything gets
     built: whatever the model decides, every build tool hard-errors until
     the planner is open (a tool error is impossible to ignore, a prompt
     hint is not) */
  if (WRITE_TOOLS.has(name) && activeTrip(useTrip.getState())?.phase === 'interview') {
    throw new Error(
      "Il viaggio è ancora in fase intervista: chiama PRIMA start_planning (apre il planner e salva il brief), POI costruisci giorni, tappe, checklist e consigli.",
    )
  }
  return await fn(args ?? {})
}

/* revert one edit using the inverse op captured at execution time */
export function applyUndoOp(u) {
  const s = useTrip.getState()
  switch (u.op) {
    case 'remove_item': s.removeItem(u.dayId, u.itemId); break
    case 'insert_item': s.insertItemAt(u.dayId, u.index, u.item); break
    case 'update_item': s.updateItem(u.dayId, u.itemId, u.patch); break
    case 'relocate_item': s.relocateItem(u.itemId, u.dayId, u.index); break
    case 'remove_day': s.removeDay(u.dayId); break
    case 'insert_day': s.insertDayAt(u.index, u.day); break
    case 'update_day': s.updateDay(u.dayId, u.patch); break
    case 'move_day': s.moveDay(u.dayId, u.dir); break
    case 'set_meta':
      s.setTitle(u.prev.title)
      s.setStartDate(u.prev.startDate)
      s.setCar(u.prev.car)
      if (u.prev.subtitle !== undefined) s.setSubtitle(u.prev.subtitle)
      if (u.prev.transport !== undefined) s.setTransport(u.prev.transport)
      break
    case 'check_remove': s.removeCheck(u.id); break
    case 'add_suggestion': s.addSuggestion(u.sug); break
    case 'remove_suggestion': s.removeSuggestion(u.id); break
    case 'check_insert': s.insertCheckAt(u.index, u.item); break
    case 'check_toggle': s.toggleCheck(u.id); break
    default: throw new Error('Undo non supportato: ' + u.op)
  }
}
