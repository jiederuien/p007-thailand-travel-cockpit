import { redirect } from 'next/navigation';

export default function Home() {
  redirect('/p007-friend-itinerary.html');
}
